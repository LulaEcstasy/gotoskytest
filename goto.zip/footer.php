<footer style="position: fixed; bottom: 0; width: 100%; font-size: 17px; color: #E9A8EA;">
 <small><br>Version 0.1</small>
</footer>

</html>