
<header>
<div class="container">
<div class="bg-img"></div>
<div class="topnav">
  <a href="../home.php">Home</a>
  <a href="../dziennik.php">Dziennik</a>
  <a href="muzyczky">Muzyczky</a>
  <a href="../info.php">Info</a>
</div></div>
</header>
<?php include('footer.php'); ?>