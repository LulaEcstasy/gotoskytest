<?php $title = 'Gotosky'; ?>
<?php $metaTags = 'tag1 tag2'; ?>
<?php include('head.php'); ?>
<?php include('navbar.php'); ?>