<?php $title = 'Gotosky'; ?>
<?php $metaTags = 'tag1 tag2'; ?>
<?php include('head.php'); ?>
<?php include('navbar.php'); ?>
<style>
body {
font-family: 'Source Sans Pro', sans-serif;
display: inline-block;
margin-top: 250px;
vertical-align: top; 
}
</style>