<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="author" content="Kamil Gotowski">
<title>Lulek</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<script src="w3.js"></script>
<link rel="stylesheet" href="../style/style.css">
<link rel="stylesheet" href="../style/style-navbar.css">
</head>
